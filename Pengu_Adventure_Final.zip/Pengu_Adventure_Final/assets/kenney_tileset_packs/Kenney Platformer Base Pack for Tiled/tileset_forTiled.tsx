<?xml version="1.0" encoding="UTF-8"?>
<tileset name="tileset_forTiled" tilewidth="70" tileheight="70" spacing="2" margin="2">
 <image source="tileset_forTiled.png" width="1024" height="1024"/>
</tileset>
